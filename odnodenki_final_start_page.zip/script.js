
document.querySelector(".registration-form").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Регистрация пока в демо-режиме.");
});
